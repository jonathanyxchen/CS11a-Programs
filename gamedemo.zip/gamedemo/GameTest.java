package gamedemo;

public class GameTest{
  public static void main(String[] args){
   BankAccount a1 = new BankAccount();
   a1.name="Tim's Gold";
   a1.balance = 1000;

   BankAccount a2 = new BankAccount();
   a2.name="William's Gold";
   a2.balance = 250;

   System.out.println("a1="+a1);
   System.out.println("a2="+a2);

   // deposit 10000 into a1
   a1.deposit(10000);
   // withdraw 50 from a2
   a2.withdraw(50);
   // transfer 100 from a1 to a2
   a1.transferTo(100,a2);

   // printout the balance from a1 and a2
   System.out.println("Tim has "+a1.getBalance()+" gold pieces");
   System.out.println("Will has "+a2.getBalance()+" gold pieces");

  }
}
